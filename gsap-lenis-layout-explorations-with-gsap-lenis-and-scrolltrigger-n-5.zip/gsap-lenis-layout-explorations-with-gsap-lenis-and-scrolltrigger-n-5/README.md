# [gsap/lenis] ❍ Layout Explorations with Gsap, Lenis and ScrollTrigger N°5

A Pen created on CodePen.

Original URL: [https://codepen.io/Octagon-Ron/pen/JodYBLx](https://codepen.io/Octagon-Ron/pen/JodYBLx).

