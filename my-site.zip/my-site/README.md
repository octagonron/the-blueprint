# My Site

A Pen created on CodePen.

Original URL: [https://codepen.io/Octagon-Ron/pen/QwbjByK](https://codepen.io/Octagon-Ron/pen/QwbjByK).

Using simple CSS background-clip technique, the text can be made to show like its under the spotlight and shining in the dark.