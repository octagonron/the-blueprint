# Additive creature

A Pen created on CodePen.

Original URL: [https://codepen.io/Octagon-Ron/pen/QwbjBmv](https://codepen.io/Octagon-Ron/pen/QwbjBmv).

Made with anime.js v4 (https://animejs.com)