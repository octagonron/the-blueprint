# Scroll-Based Word Reveal with Gradient Transition

A Pen created on CodePen.

Original URL: [https://codepen.io/jerora98/pen/dyxYPPj](https://codepen.io/jerora98/pen/dyxYPPj).

A smooth scroll-triggered animation that reveals each word line-by-line. Perfect for storytelling websites, creative portfolios, or modern text-heavy landing pages with a dark gradient aesthetic.